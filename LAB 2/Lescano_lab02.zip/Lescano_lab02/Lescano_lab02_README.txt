PARAMETERS:
Sigma1: 5
Size1: 50
Frequencies from Image 1: high
Sigma2: 10
Size2: 10
Frequencies from Image 2: low
Mix-in Ratio: 0.5
Image 1's higher frequencies are used.
