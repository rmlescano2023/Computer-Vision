1. Read Chapter 1 and 2 of Howse book
2. Run the codes [123456]-*.py
2. Watch the video https://fb.watch/pWLNqOIQPE/
3. Given a square image, create a program that replicates the process as shown in the video.
That is, 
	3.1) divide the image horizontally into equally-spaced strips
	3.2) assemble into two images by taking every other strip to form one image
	3.3) merge the two images
	3.4) divide the merged image vertically into equally-spaced strips
	3.5) assemble into two images again by taking every other strip to form one image
	3.6) merge the two images
