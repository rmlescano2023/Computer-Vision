What is the coolest/most interesting thing you learned from this laboratory exercise?

Gabriel Venz Badilles
- The coolest thing I learned from this laboratory exercise is how to use morphological operations to clean up binary images.
By applying techniques like Gaussian blur and morphological opening, we can significantly enhance image quality, making contour
detection more accurate. This preprocessing step is crucial for many computer vision exercises.

Renmar Lescano
- The most interesting thing I learned from this laboratory exercise is how to build a machine learning model that predicts volumes
from image features. We trained a model that can estimate the volume of liquid in containers based on image data. This application of machine learning to real-world image processing
tasks is fascinating and very cool!