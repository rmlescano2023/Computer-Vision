Do-it-yourself (DIY) Pinhole Camera
(individual or groups of two or three)

Create a classroom model pinhole camera.


Submission
Bring your DIY pinhole camera during F2F lab class and demonstrate how it works.

